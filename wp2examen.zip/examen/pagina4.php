<?php
session_start();
include 'dbcon.php';

# alle Sessions in variabelen zetten zodat die makkelijker in de sql query kunnen.
if (isset($_POST['submit3'])) {
    $rijder = $_SESSION['rijder'];
    $van = $_SESSION['van'];
    $naar = $_SESSION['naar'];
    $afstand = $_SESSION['afstand'];
    $start_uur = $_SESSION['start-uur'];
    $start_minuut = $_SESSION['start-minuut'];
    $eind_uur = $_SESSION['eind-uur'];
    $eind_minuut = $_SESSION['eind-minuut'];
    $datum = $_SESSION['datum'];
    $Ritprijs = $_SESSION['Ritprijs'];
    $Naampersoon =  $_SESSION["naam"];
    $Betaalmethode =  $_SESSION["betaalmethode"];

# insert alle gegevens in de database (taxicentrale) --> table --> (ritregistratie)
  $sql = "INSERT INTO ritregistratie ( `Rijder`, `Van`, `Naar`, `Afstand`, `Startuur`, `Startminuut`, `Einduur`, `Eindminuut`, `Datum`, `Ritprijs`, `Naampersoon` , `Betaalmethode` ) 
  VALUES ('$rijder','$van','$naar','$afstand','$start_uur','$start_minuut','$eind_uur','$eind_minuut','$datum','$Ritprijs','$Naampersoon', '$Betaalmethode')";

  if ($conn->query($sql) === TRUE) {
    echo "<h1>Taxi registratie geupload<h1>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();
} 
?>

<!DOCTYPE html>
<html>
      <head>
          <title>Pagina 4</title>
          <link rel="stylesheet" href="mystyle.css">
      </head>
    <body>
       <a href="http://localhost:8888/examen/pagina1.php">Terug naat home</a>
    </body>
</html>

