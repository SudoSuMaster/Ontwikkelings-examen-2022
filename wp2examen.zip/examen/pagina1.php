<?php
include 'dbcon.php';
?>

<!DOCTYPE html>
<html>
<head>
<title>Pagina 1</title>
<link rel="stylesheet" href="mystyle.css">
</head>
    <body>

    <h1>TAXI RIT</h1>
    <!-- Formulier inputs 1-->
        <form action="http://localhost:8888/examen/pagina2.php" method="post">
            <table>
        <!-- input 1 (Rijder). -->    
                    <tr>
                        <th>Voer de rijder in</th>
                        <td><input type="text"  name="rijder" required></td>
                    <tr>
        <!-- input 2 (Van). -->  
                    </tr>
                        <th>Voer de Start locatie in</th>
                        <td><input type="text"  name="van" required></td>
                        </tr>
        <!-- input 3 (Naar). -->  
                    <tr>
                        <th>Voer de eindbestemming in </th>
                        <td><input type="text"  name="naar" required></td>
                    <tr>
        <!-- input 4 (Afstand in KM). -->  
                    <tr>
                        <th>Voer de afstand in Kilometers in</th>
                        <td><input type="number" name="afstand" step="any" required></td>
                    <tr>
        <!-- input 5 (Start-uur). -->  
                    <tr>
                        <th>Voer de start uur in (MAX24)</th>
                        <td><input type="number" name="start-uur" max="24" required></td>
                    <tr>
        <!-- input 6 (Start-Minuut). -->  
                    <tr>
                        <th>voer de start minuten in (MAX 60)</th>
                        <td><input type="number" name="start-minuut" max="60" required> </td>
                    <tr>   
                        
        <!-- input 7 (Eind-uur). -->  
                    <tr>
                        <th>Voer de eind uur in (MAX24)</th>
                        <td><input type="number" name="eind-uur" max="24" required></td>
                    <tr>    

        <!-- input 8 (Eind-Minuut). -->  
                    <tr>
                        <th>Voer de eind minuten in (MAX60)</th>
                        <td><input type="number" name="eind-minuut" max="60" required></td>
                    <tr>  

        <!-- input 9 (Datum) LET OP!!! datum is een text type en geen datum type, dit is omdat
        in de veld varchar (8) wordgebruikt waardoor als (21-01-2004) invoerd dit te lang is voor column. -->  
                    <tr>
                        <th>Datum voer de datum in (Voorbeeld: 22062022)</th>
                        <td><input type="text" name="datum"  maxlength="8" required></td>
                    <tr> 
            </table>
            <button name="submit1" type="submit" value="submit1">Volgende</button>
        </form>
    </body>
</html>
