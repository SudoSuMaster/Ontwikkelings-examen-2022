-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 30 jun 2022 om 10:29
-- Serverversie: 5.6.51
-- PHP-versie: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taxicentrale`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ritregistratie`
--

CREATE TABLE `ritregistratie` (
  `id` int(11) NOT NULL,
  `Rijder` varchar(40) NOT NULL,
  `Van` varchar(40) NOT NULL,
  `Naar` varchar(40) NOT NULL,
  `Afstand` decimal(10,0) NOT NULL,
  `Startuur` int(11) NOT NULL,
  `Startminuut` int(11) NOT NULL,
  `Einduur` int(11) NOT NULL,
  `Eindminuut` int(11) NOT NULL,
  `Datum` varchar(8) NOT NULL,
  `Ritprijs` decimal(10,0) NOT NULL,
  `Naampersoon` varchar(20) NOT NULL,
  `Betaalmethode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `ritregistratie`
--

INSERT INTO `ritregistratie` (`id`, `Rijder`, `Van`, `Naar`, `Afstand`, `Startuur`, `Startminuut`, `Einduur`, `Eindminuut`, `Datum`, `Ritprijs`, `Naampersoon`, `Betaalmethode`) VALUES
(7, 'Levano', 'Eindhoven', 'Rotterdam', '6', 17, 45, 19, 3, '21012004', '3', 'lala', 'Contant'),
(8, 'Levano', 'Eindhoven', 'Rotterdam', '6', 17, 45, 19, 3, '21012004', '3', 'lala', 'Contant'),
(9, 'Levano', 'Nure', 'Antwerpen', '56', 18, 56, 22, 45, '30062004', '30', 'Levano', 'Visa '),
(10, 'Levano', 'Eindhoven', 'Rotterdam', '6', 17, 45, 19, 3, '21012004', '3', 'Obama', 'Contant'),
(11, 'Levano', 'Eindhoven', 'Rotterdam', '45', 18, 16, 22, 60, '', '25', 'Levano', 'Contant'),
(12, 'Levano', 'Eindhoven', 'Rotterdam', '45', 18, 16, 22, 60, '', '25', 'Levano', 'Contant'),
(13, 'Levano', 'Eindhoven', 'Rotterdam', '45', 18, 16, 22, 60, '', '25', 'Levano', 'Contant'),
(14, 'Levano', 'Eindhoven', 'Rotterdam', '45', 18, 16, 22, 60, '', '25', 'Levano', 'Contant');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `ritregistratie`
--
ALTER TABLE `ritregistratie`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `ritregistratie`
--
ALTER TABLE `ritregistratie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
