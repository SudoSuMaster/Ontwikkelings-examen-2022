<?php 


function dropdown(){
        #Functie dropdown met array 
        $betaalmethode  = array("Contant", "Visa ", "Mastercard");
        echo '<label for="afdeling">Kies uw betaalmethode</label>';
        echo '<select name="betaalmethode">';

        foreach ($betaalmethode as $value){
            echo '<option value="'.$value.'" required >'.$value.' </option>';
        }
        echo '</select>';
}

function prijs(){
        $prijsprkm =  0.50;
        #Toeslag formule tussen 18:00 en voor 06:00 toeslag van 2 euro
        if ($_SESSION["start-uur"] >('17.99') OR $_SESSION["start-uur"] < ('6.01')  ) {
            $Ritprijs = $_SESSION["afstand"]*$prijsprkm+2;
            echo "<br>";
            echo $Ritprijs . "Euro's";
            $_SESSION['Ritprijs'] = $Ritprijs;
        } else {
        #Formule prijs per kilometer x kilometer zonder toeslag!
            $Ritprijs = $_SESSION["afstand"]*$prijsprkm;
            echo "<br>";
            echo $Ritprijs. "Euro's";
            $_SESSION['Ritprijs'] = $Ritprijs;
        }
}

function image(){
        #Foto weergeven van de geselecteerde betaal methode 
        if ($_SESSION["betaalmethode"] == "Contant"){
            $filepath= 'image\cont.png'; 
            echo '<img src="'.$filepath.'">'; 
        }  elseif  ($_SESSION["betaalmethode"] == "Mastercard"){
                $filepath= 'image\mastr.png'; 
                echo '<img width="128" height="128" src="'.$filepath.'">';
          } else{
            $filepath= 'image\visa-logo-800x450.jpg'; 
            echo '<img src="'.$filepath.'">';
          }
}


