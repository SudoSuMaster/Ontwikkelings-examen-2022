<?php
session_start();
include 'dbcon.php';
include 'functies.php';

# Betaal methode en naam POST omzetten naar een session
if (isset($_POST['submit2'])) {
    $_SESSION["betaalmethode"] = $_POST['betaalmethode'];
    $_SESSION["naam"] = $_POST['naam'];
  } 
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Pagina 3</title>
        <link rel="stylesheet" href="mystyle.css">
    </head>
    <body>
    <h1>Prijs overzicht</h1>
    <table>
<!-- show 1 (Rijder). -->    
            <tr>
                <th>Rijder</th>
                <td><?php echo $_SESSION['rijder'];?></td>
            <tr>
<!-- show 2 (Van). -->  
            </tr>
                <th>Van</th>
                <td><?php echo $_SESSION['van'];?></td>
                </tr>
<!-- show 3 (Naar). -->  
            <tr>
                <th>Naar</th>
                <td><?php echo $_SESSION['naar'];?></td>
            <tr>
<!-- show 4(Afstand in KM). -->  
            <tr>
                <th>Afstand in KM</th>
                <td><?php echo $_SESSION['afstand'];?></td>
            <tr>
<!-- show 4 (Start-uur). -->  
            <tr>
                <th>Start-uur</th>
                <td><?php echo $_SESSION['start-uur'];?></td>
            <tr>
<!-- show 5 (Start-Minuut). -->  
            <tr>
                <th>Start-Minuut</th>
                <td><?php echo $_SESSION['start-minuut'];?></td>
            <tr>   
                
<!--show 6 (Eind-uur). -->  
            <tr>
                <th>Eind-uur</th>
                <td><?php echo $_SESSION['eind-uur'];?></td>
            <tr>    

<!-- show 7 (Eind-Minuut). -->  
            <tr>
                <th>Eind-Minuut</th>
                <td><?php echo $_SESSION['eind-minuut'];?></td>
            <tr>  
<!-- show 8 (Datum). -->  
            <tr>
                <th>Datum</th>
                <td><?php echo $_SESSION['datum'];?></td>
            <tr> 

<!-- show 9 (betaalmethode). -->  
<!-- include image function. -->  
            <tr>
                <th>betaalmethode</th>
                <td><?php echo $_SESSION["betaalmethode"]. "<br>";  image()?></td>
            <tr> 
<!-- show 10 (naam). -->  
            <tr>
                <th>naam</th>
                <td><?php echo $_SESSION["naam"];?></td>
            <tr> 
<!-- show 11 (Ritprijs). -->  
            <tr>
                <th>Ritprijs</th>
                <td><?php echo $_SESSION['Ritprijs'];?></td>
            <tr> 

    </table>
            <form action="http://localhost:8888/examen/pagina4.php" method="post">
                <button name="submit3" type="submit" value="submit3">Opslaan</button>
        </form>
    </body>
</html>