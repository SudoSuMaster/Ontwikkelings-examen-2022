<?php
session_start();
include 'dbcon.php';
include 'functies.php';

# Session aangemaakt van de POSTS op pagina 1
if (isset($_POST['submit1'])) {
    $_SESSION["rijder"] = $_POST['rijder'];
    $_SESSION["van"] = $_POST['van'];
    $_SESSION["naar"] = $_POST['naar'];
    $_SESSION["afstand"] = $_POST['afstand'];
    $_SESSION["start-uur"] = $_POST['start-uur'];
    $_SESSION["start-minuut"] = $_POST['start-minuut'];
    $_SESSION["eind-uur"] = $_POST['eind-uur'];
    $_SESSION["eind-minuut"] = $_POST['eind-minuut'];
    $_SESSION["datum"] = $_POST['datum'];
  } 
?>



<!DOCTYPE html>
<html>
<head>
<title>Pagina 2</title>
<link rel="stylesheet" href="mystyle.css">
</head>
    <body>

    <h1>Prijs overzicht</h1>
    <!-- Formulier inputs 2-->
        <form action="http://localhost:8888/examen/pagina3.php" method="post">
                <table>
             <!-- input 1 (Ritprijs). -->  
                        <tr>
                            <th>Ritprijs</th>
                            <td><?php prijs()?></td>
                        <tr> 
            <!-- input 2 (vervoerde). -->    
                        <tr>
                            <th>Naam van vervoerde persoon</th>
                            <td><input type="text"  name="naam" ></td>
                        <tr> 
            <!-- input 3 (betaalmethode). -->              
                        </tr>
                            <th>Selecteer een betaalmethode</th>          
                            <td><?php dropdown()?></td>          
                        </tr>                  
                </table>
                <button name="submit2" type="submit" value="submit2">Volgende</button>
        </form>
    </body>
</html>